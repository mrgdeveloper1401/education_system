import pandas as pd
import django
import os

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "education_system.envs.development")
django.setup()

from accounts.models import State, City

read_json = pd.read_json("data.json")


for i, j in read_json.iterrows():
    province, _ = State.objects.get_or_create(state_name=j['name'])
    for city in j['cities']:
        City.objects.get_or_create(state=province, city=city)
