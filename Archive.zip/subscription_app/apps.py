from django.apps import AppConfig


class SubscriptionAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "subscription_app"
